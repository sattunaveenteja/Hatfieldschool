

import java.util.List;
import lessonbooking.Feedbacks;
import lessonbooking.LessonReservations;
import static lessonbooking.LessonReservations.BOOKED;
import static lessonbooking.LessonReservations.CANCEL;
import static lessonbooking.LessonReservations.CHANGE;
import lessonbooking.LessonsData;
import lessonbooking.SignedInUser;
import lessonbooking.Students;
import org.junit.Test;
import static org.junit.Assert.*;

public class LessonBookingTestClass {
    
 
    @Test
    public void testcase1_filterByCoach() {

        String instructor = "denny" ;
        System.out.println("\nFilter By Instructor : "+instructor);
        LessonsData.viewLessons("","",instructor);
        assertTrue(!LessonsData.lessonDataInformation.isEmpty());
    }
     
     
    
 
    @Test
    public void testcase2_book() {
        LessonReservations obj2 = new LessonReservations(38, 5,16,BOOKED );
        LessonReservations obj3 = new LessonReservations(76, 2,2,BOOKED );

        LessonReservations.reservationInformation.add(obj2);
        LessonReservations.reservationInformation.add(obj3);
        
        assertTrue(!LessonReservations.reservationInformation.isEmpty());
    }
     
     
    
 
    @Test
    public void testcase3_change() {
        LessonReservations objs = new LessonReservations(36, 1,3,BOOKED );
        LessonReservations.reservationInformation.add(objs);
        int reservationNo = 36;
        int lessonSelected = 6;
        //Update new lesson ans status
        int lessonID = 0;
        List<LessonReservations> reservationInformation = LessonReservations.getReservationInformation();
        for(LessonReservations obj : reservationInformation){
            if(obj.getBookingNo() == reservationNo){
                lessonID = obj.getBookingFor();
                obj.setBookingFor(lessonSelected);
                obj.setBookingStatus(CHANGE);
                break;
            }
        }
         //Update available seats by decreasing by 1
        LessonsData.setSeats(lessonSelected,1,0);
        //Update available seats by increasing by 1
        LessonsData.setSeats(lessonID,0,1);
        String status = "";
        for(LessonReservations obj : reservationInformation){
            if(obj.getBookingNo() == reservationNo){
               status = obj.getBookingStatus();
                break;
            }
        }
        assertTrue(status.equalsIgnoreCase(CHANGE));
    }
     
     
    
 
    @Test
    public void testcase4_cancel() {        
        int reservationNo = 76;
        //Upadte status
        int lessonID = 0;
        List<LessonReservations> reservationInformation = LessonReservations.getReservationInformation();
        for(LessonReservations obj : reservationInformation){
            if(obj.getBookingNo() == reservationNo){
                lessonID = obj.getBookingFor();
                obj.setBookingStatus(CANCEL);
                break;
            }
        }
        //Update available seats by decreasing by 1
        LessonsData.setSeats(lessonID,0,1);
        String status = "";
        for(LessonReservations obj : reservationInformation){
            if(obj.getBookingNo() == reservationNo){
               status = obj.getBookingStatus();
                break;
            }
        }
        assertTrue(status.equalsIgnoreCase(CANCEL));
    }
     
     
    
 
    @Test
    public void testcase5_feedback() {          
        int reservationNo = 38;
        List<LessonReservations> reservationInformation = LessonReservations.getReservationInformation();
        List<LessonsData> lessonsDataInformation = LessonsData.getLessonDataInformation();
        int lessonUniqueID = 0;
         for(LessonReservations obj : reservationInformation){
            if(obj.getBookingNo() == reservationNo){
                for(LessonsData lessondataObj : lessonsDataInformation){
                    if(obj.getBookingFor() == lessondataObj.getLessonUniqueNo()){
                        lessonUniqueID = lessondataObj.getLessonUniqueNo();
                        break;
                    }
                }
            }
        }
        Feedbacks obj = new Feedbacks(reservationNo,1,lessonUniqueID,4,"OKK");
        Feedbacks.feedbackInformation.add(obj);
        
        //Update status
        for(LessonReservations obj1 : reservationInformation){
            if(obj1.getBookingNo() == reservationNo){
                obj1.setBookingStatus(LessonReservations.ATTEND);
                break;
            }
        }
        //Update available seats by increasing by 1
        LessonsData.setSeats(lessonUniqueID,0,1);
        //Update grade of student if attended higher grade class
        Students.incStudentGrade(1,lessonUniqueID);
        String status = "";
        for(LessonReservations obj1 : reservationInformation){
            if(obj1.getBookingNo() == reservationNo){
               status = obj1.getBookingStatus();
                break;
            }
        }
        assertTrue(status.equalsIgnoreCase(LessonReservations.ATTEND));

    }
     
     
     
}
