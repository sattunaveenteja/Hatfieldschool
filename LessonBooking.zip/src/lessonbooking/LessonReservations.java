
package lessonbooking;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;


public class LessonReservations {
    
    private int reservationNo;
    private int reservationDoneBy;
    private int reservationFor;
    private String reservationStatus;
   
    public static int IS_BOOKING = 0;
    public static int IS_CHANGING = 0;
    public static int CHANGING_BOOKING_ID = 0;
    
    public static final String BOOKED = "Booked";
    public static final String CHANGE = "Changed";
    public static final String ATTEND = "Attended";
    public static final String CANCEL = "Cancelled";

    
    public static List <LessonReservations> reservationInformation = new ArrayList<>();

    public LessonReservations(int reservationNo, int reservationDoneBy, int reservationFor, String reservationStatus) {
        this.reservationNo = reservationNo;
        this.reservationDoneBy = reservationDoneBy;
        this.reservationFor = reservationFor;
        this.reservationStatus = reservationStatus;
    }

    public int getBookingNo() {
        return reservationNo;
    }

    public int getBookingDoneBy() {
        return reservationDoneBy;
    }

    public int getBookingFor() {
        return reservationFor;
    }

    public String getBookingStatus() {
        return reservationStatus;
    }

    public static List<LessonReservations> getReservationInformation() {
        return reservationInformation;
    }

    public void setBookingFor(int reservationFor) {
        this.reservationFor = reservationFor;
    }

    public void setBookingStatus(String reservationStatus) {
        this.reservationStatus = reservationStatus;
    }

      //Book class
    public static void book(){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("\nEnter 1 to Make Reservation");
        System.out.println("Enter 2 to Go Back to Main Menu");
        
        System.out.print("\nPlease Enter your Choice : ");
        String choice = sc.nextLine();
        
        //Validations
        if(choice.equalsIgnoreCase("")){
           do{
                System.out.print("\nPlease Enter your Choice : ");
                choice = sc.nextLine();
            }while(choice.equalsIgnoreCase("")); 
        }
        
       
        if(choice.equalsIgnoreCase("") || !(choice.equalsIgnoreCase("1") || choice.equalsIgnoreCase("2"))){
            do{
                System.out.print("\nPlease Enter your Choice : ");
                choice = sc.nextLine();
            }while(choice.equalsIgnoreCase("") || !(choice.equalsIgnoreCase("1") || choice.equalsIgnoreCase("2")));
        }
        
         if(choice.equalsIgnoreCase("2")){
           return;
        }
        
        //Take Lesson Choice
        System.out.print("\nEnter Your Choice of Class Lesson No : ");
        String lessonSelected = sc.nextLine();
        if(choice.equalsIgnoreCase("1")){
            if(lessonSelected.equalsIgnoreCase("")){
                do{
                    System.out.print("\nEnter Your Choice of Class Lesson No : ");
                    lessonSelected = sc.nextLine();
                }while(lessonSelected.equalsIgnoreCase(""));
            }
        }
        
        //Check lesson Class ID
        boolean checkLessonUniqueID = LessonsData.checkLessonUniqueID(Integer.parseInt(lessonSelected));
        if(!checkLessonUniqueID){
            System.out.println("\nLesson Unique No is not valid");
            return;
        }
        
        //If No Seat
        boolean checkAvailableSeats = LessonsData.checkAvailableSeats(Integer.parseInt(lessonSelected));
        if(checkAvailableSeats){
            System.out.println("\nNo Seat is available");
            return;
        }
        
        
        //Is reservation twice
        boolean checkTwiceReservationByStudent = checkTwiceReservationByStudent(Integer.parseInt(lessonSelected), SignedInUser.STUDENT_UNIQUE_ROLL_NO);
        if(checkTwiceReservationByStudent){
            System.out.println("\nYou cannot reserve lesson twice.");
            return;
        }
        
        //Is lesson of Current Grade level
        boolean validateIsOfCurrentGrade = LessonsData.checkLessonGrade(SignedInUser.STUDENT_UNIQUE_ROLL_NO,
                Integer.parseInt(lessonSelected));
        if(validateIsOfCurrentGrade){
                System.out.println("\nYou cannot reserve lesson which is lower or higher than your current grade level.");
                return;
        }
               
        Random random = new Random();
        int studentBookingID = random.nextInt(100);
        int reservationNo = studentBookingID;
        
        LessonReservations obj = new LessonReservations(reservationNo, SignedInUser.STUDENT_UNIQUE_ROLL_NO,
                Integer.parseInt(lessonSelected),BOOKED );
        LessonReservations.reservationInformation.add(obj);
        
        //Update available seats by decreasing by 1
        LessonsData.setSeats(Integer.parseInt(lessonSelected),1,0);
        
        System.out.println("\nYour Reservation has been successful with us. Your Reservation No : "+reservationNo);
        LessonReservations.IS_BOOKING = 0;
        return;        
    }
        
    //Change class
    public static void change(){
        Scanner sc = new Scanner(System.in);
        
        //Take Lesson Choice
        System.out.print("\nEnter Reservation No : ");
        String reservationID = sc.nextLine();
        int reservationNo = Integer.parseInt(reservationID);
        
        //Check Reservation No
        boolean checkReservationID = checkReservationID(reservationNo);
        if(!checkReservationID){
            System.out.println("\nReservation No is not valid.");
            return;
        }
        
        //Is Already cancelled or attended
        boolean checkReservationStatus = checkReservationStatus(reservationNo);
        if(checkReservationStatus){
            System.out.println("\nYou have already attended or cancelled given Reservation No");
            return;
        }
        
        LessonReservations.CHANGING_BOOKING_ID = reservationNo;
        System.out.println("\nSelect New Lesson To Change : ");

        LessonsData.filterOnLessonsMenu();
        LessonReservations.CHANGING_BOOKING_ID = 0;
        LessonReservations.IS_CHANGING = 0;
    }
        
        
    //Change class with new lesson
    public static void updateReservation(){
        Scanner sc = new Scanner(System.in);
        int reservationNo = LessonReservations.CHANGING_BOOKING_ID;

        System.out.print("\nEnter Your Choice of Lesson No : ");
        String lessonSelected = sc.nextLine();
        if(lessonSelected.equalsIgnoreCase("")){
            do{
                System.out.print("\nEnter Your Choice of Lesson No : ");
                lessonSelected = sc.nextLine();
            }while(lessonSelected.equalsIgnoreCase(""));
        }
        
        //Validate lesson Class ID
        boolean validateLessonChoice = LessonsData.checkLessonUniqueID(Integer.parseInt(lessonSelected));
        if(!validateLessonChoice){
            System.out.println("\nLesson No is not valid.");
            return;
        }
          
        //If No Seat
        boolean checkAvailableSeats = LessonsData.checkAvailableSeats(Integer.parseInt(lessonSelected));
        if(checkAvailableSeats){
            System.out.println("\nNo Seat is available.");
            return;
        }
      
        //Is booking duplicate
        boolean validateDuplicateBooking = checkTwiceReservationByStudent(Integer.parseInt(lessonSelected), SignedInUser.STUDENT_UNIQUE_ROLL_NO);
        if(validateDuplicateBooking){
            System.out.println("\nYou cannot reserve lesson twice.");
            return;
        }
               
        //Is lesson of Current Grade level
        boolean validateIsOfCurrentGrade = LessonsData.checkLessonGrade( SignedInUser.STUDENT_UNIQUE_ROLL_NO, 
                Integer.parseInt(lessonSelected));
        if(validateIsOfCurrentGrade){
                System.out.println("\nYou cannot reserve lesson which is lower or higher than your current grade level.");
                return;
        }
        
        //Update new lesson ans status
        int lessonID = 0;
        List<LessonReservations> reservationInformation = LessonReservations.getReservationInformation();
        for(LessonReservations obj : reservationInformation){
            if(obj.getBookingNo() == reservationNo){
                lessonID = obj.getBookingFor();
                obj.setBookingFor(Integer.parseInt(lessonSelected));
                obj.setBookingStatus(CHANGE);
                break;
            }
        }
         //Update available seats by decreasing by 1
        LessonsData.setSeats(Integer.parseInt(lessonSelected),1,0);
        
        //Update available seats by increasing by 1
        LessonsData.setSeats(lessonID,0,1);
        
        System.out.println("\nYour reservation has been updated with new lesson.");
        return;
    }
    
        
    //Cancel class
    public static void cancel(){
        Scanner sc = new Scanner(System.in);
        
        //Take Lesson Choice
        System.out.print("\nEnter Reservation No for which you want to cancel lesson : ");
        String reservationID = sc.nextLine();
        int reservationNo = Integer.parseInt(reservationID);
        
        //Check Reservation No
        boolean checkReservationID = checkReservationID(reservationNo);
        if(!checkReservationID){
            System.out.println("\nYou have entered incorrect Reservation No.");
            return;
        }
        
        
        //Is Already cancelled or attended
        boolean checkReservationStatus = checkReservationStatus(reservationNo);
        if(checkReservationStatus){
            System.out.println("\nYou have already attended or cancelled given Reservation No");
            return;
        }
        
        
        //Upadte status
        int lessonID = 0;
        List<LessonReservations> reservationInformation = LessonReservations.getReservationInformation();
        for(LessonReservations obj : reservationInformation){
            if(obj.getBookingNo() == reservationNo){
                lessonID = obj.getBookingFor();
                obj.setBookingStatus(CANCEL);
                break;
            }
        }
        
        //Update available seats by decreasing by 1
        LessonsData.setSeats(lessonID,0,1);
        
        System.out.println("\nYour reservation has been cancelled.");
        return;
    }
    
    
    //View Reservations
    public static void view(){
        
        List<LessonReservations> reservationInformation = LessonReservations.getReservationInformation();
        List<LessonsData> lessonDataInformation = LessonsData.getLessonDataInformation();
        List<Students> studentInformation = Students.getStudentsInformation();
        List<Instructors> instructorsInformation = Instructors.getInstructorInformation();
        
        if(reservationInformation.size() < 1){
            System.out.println("\nNo Booking Found"); 
            return;
        }

        System.out.println("\n\n-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("| %-14s | %-16s | %-13s | %-15s | %-30s | %-12s | %-15s | %-10s | %-15s | %-11s | %-8s |\n",
                "ReservationNo","ReservedBy", "StudentGrade","LessonsDataID", "Title", "LessonGrade","Day","Timing","Date", 
                "Instructor","Status");
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        
        
        Set<String> uniqueRecords = new HashSet<>(); 

        for(LessonReservations obj : reservationInformation){
            
            //Lesson Details
            String title = "";
            String classGrade = "";
            String day = "";
            String lessondate = "";
            String timing = "";
            int instructorUnqID = 0;
            for(LessonsData LessonObj : lessonDataInformation){
                if(obj.getBookingFor() == LessonObj.getLessonUniqueNo()){
                    title = LessonObj.getTitle();
                    classGrade = String.valueOf(LessonObj.getLessonGradeLevel());
                    day = LessonObj.getDayName();
                    lessondate = LessonObj.getLessonDate();
                    timing = LessonObj.getLessonTime();
                    instructorUnqID = LessonObj.getInstructorUniqueNo();
                    break;
                }
            }
            
            //Instructor Information
            String instructorName = "";
            for(Instructors iObj : instructorsInformation){
                if(iObj.getUniqueInstructorNo() == instructorUnqID ){
                    instructorName = iObj.getName();
                    break;
                }
            }
            
            
            //Student Details
            String stduentName = "";
            String studentGrade = "";
            for(Students stduntInfoObj : studentInformation){
                if(stduntInfoObj.getUniqueRollNo() == obj.getBookingDoneBy()){
                    stduentName = stduntInfoObj.getName();
                    studentGrade = String.valueOf(stduntInfoObj.getStudentsGradeLevel());
                    break;
                }
            }
            
            //Display
            if (!uniqueRecords.contains(String.valueOf(obj.getBookingNo()))){
                uniqueRecords.add(String.valueOf(obj.getBookingNo()));     
                
                //If Student
                if(SignedInUser.STUDENT_UNIQUE_ROLL_NO != 0 && obj.getBookingDoneBy() == SignedInUser.STUDENT_UNIQUE_ROLL_NO){
                      System.out.printf("| %-14s | %-16s | %-13s | %-15s | %-30s | %-12s | %-15s | %-10s | %-15s | %-11s | %-8s |\n",
                        obj.getBookingNo(),stduentName, studentGrade,obj.getBookingFor(), title, classGrade,day,
                        timing,lessondate, instructorName,obj.getBookingStatus());
                //If Admin
                }else if(SignedInUser.DIRECTOR_ID != 0){
                    System.out.printf("| %-14s | %-16s | %-13s | %-15s | %-30s | %-12s | %-15s | %-10s | %-15s | %-11s | %-8s |\n",
                        obj.getBookingNo(),stduentName, studentGrade,obj.getBookingFor(), title, classGrade,day,
                        timing,lessondate, instructorName,obj.getBookingStatus());
                }
            }
        }
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

    }
    
    
   //Check Twice Reservation No
    public static boolean checkTwiceReservationByStudent(int lessonSelected, int studentUniqueID){
        boolean isVerified = false;
        
        List<LessonReservations> reservationInformation = LessonReservations.getReservationInformation();
        for(LessonReservations obj : reservationInformation){
            if(obj.getBookingDoneBy() == studentUniqueID && obj.getBookingFor() == lessonSelected &&
                    (obj.getBookingStatus().equalsIgnoreCase(LessonReservations.BOOKED) || 
                    obj.getBookingStatus().equalsIgnoreCase(LessonReservations.CHANGE))){
                isVerified = true;
                break;
            }
        }
        return isVerified;
    }
    
    
    //Check Reservation No
    public static boolean checkReservationID(int reservationNo){
        boolean isVerified = false;
        
        List<LessonReservations> reservationInformation = LessonReservations.getReservationInformation();
        for(LessonReservations obj : reservationInformation){
            if(obj.getBookingNo() == reservationNo){
                isVerified = true;
                break;
            }
        }
        return isVerified;
    }
    
    
    //Validate booking status
    public static boolean checkReservationStatus(int reservationNo){
        boolean isVerified = false;
        
        List<LessonReservations> reservationInformation = LessonReservations.getReservationInformation();
        for(LessonReservations obj : reservationInformation){
            if(obj.getBookingNo() == reservationNo &&
                    (obj.getBookingStatus().equalsIgnoreCase(LessonReservations.ATTEND) ||
                    obj.getBookingStatus().equalsIgnoreCase(LessonReservations.CANCEL))){
                isVerified = true;
                break;
            }
        }
        return isVerified;
    }
    
    
    
}
