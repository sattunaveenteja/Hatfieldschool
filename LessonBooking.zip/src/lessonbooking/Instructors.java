
package lessonbooking;

import java.util.ArrayList;
import java.util.List;


public class Instructors {
    
    private int uniqueInstructorNo;
    private String name;
    private String phoneNum;
  
    public static List <Instructors> instructorInformation = new ArrayList<>();

    public Instructors(int uniqueInstructorNo, String name, String phoneNum) {
        this.uniqueInstructorNo = uniqueInstructorNo;
        this.name = name;
        this.phoneNum = phoneNum;
    }

    public int getUniqueInstructorNo() {
        return uniqueInstructorNo;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public static List<Instructors> getInstructorInformation() {
        Instructors i1 = new Instructors(1,"Sandy","01208 850382");
        Instructors i2 = new Instructors(2,"Wilson","01726 63999");
        Instructors i3 = new Instructors(3,"Isobel","020 7622 2530");
        Instructors i4 = new Instructors(4,"Denny","01929 552177");
        
        Instructors.instructorInformation.add(i1);
        Instructors.instructorInformation.add(i2);
        Instructors.instructorInformation.add(i3);
        Instructors.instructorInformation.add(i4);
        
        return instructorInformation;
    }
    
    
    
    
    
}
