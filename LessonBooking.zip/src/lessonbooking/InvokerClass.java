
package lessonbooking;


public class InvokerClass {
    
    private CommandInterface CommandInterface;

    public void setCommand(CommandInterface CommandInterface) {
        this.CommandInterface = CommandInterface;
    }

    public void displayReport() {
        this.CommandInterface.generate();
    }
    
    
    
}
