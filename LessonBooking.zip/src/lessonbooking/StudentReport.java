
package lessonbooking;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class StudentReport implements CommandInterface{
    
    @Override
    public void generate() {
        
        String  month = getMonthNum();
       
        List<LessonReservations> reservationnformation = LessonReservations.getReservationInformation();
        List<LessonsData> lessonInfo = LessonsData.getLessonDataInformation();
        List<Students> studentInfo = Students.getStudentsInformation();
        List<Instructors> instructorsInformation = Instructors.getInstructorInformation();

        System.out.println();

        HashMap<Integer, int[]> students = new HashMap<>();
        Set<String> uniqueLearnerCode = new HashSet<>();             
        for (int j = 0; j < reservationnformation.size(); j++) {

            for (int i = 0; i < studentInfo.size(); i++) {
                String monthNumber = "";
                for (LessonsData lessonDataObj : lessonInfo) {

                    if(lessonDataObj.getLessonUniqueNo() == reservationnformation.get(j).getBookingFor()){
                        //Parse timetable classOn field
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");                

                        try {
                            LocalDateTime parsedDateTime = LocalDate.parse(lessonDataObj.getLessonDate(), formatter).atStartOfDay();
                            monthNumber = parsedDateTime.format(DateTimeFormatter.ofPattern("M"));
                        } catch (DateTimeParseException e) {
                            System.out.println("Error parsing datetime: " + e.getMessage());
                        }
                        break;
                    }
                }

                String uniqueKey = String.valueOf(studentInfo.get(i).getUniqueRollNo()) + reservationnformation.get(j).getBookingNo();

                if (!uniqueLearnerCode.contains(uniqueKey)) {
                    uniqueLearnerCode.add(uniqueKey);

                    if (studentInfo.get(i).getUniqueRollNo() == reservationnformation.get(j).getBookingDoneBy() && 
                            monthNumber.equalsIgnoreCase(month)) {

                        int uniqueCode = studentInfo.get(i).getUniqueRollNo();
                        int[] counter = students.getOrDefault(uniqueCode, new int[3]);

                        if (reservationnformation.get(j).getBookingStatus().equalsIgnoreCase(LessonReservations.BOOKED) 
                                || reservationnformation.get(j).getBookingStatus().equalsIgnoreCase(LessonReservations.CHANGE)) {
                            counter[0]++;
                        }
                        if (reservationnformation.get(j).getBookingStatus().equalsIgnoreCase(LessonReservations.CANCEL)) {
                            counter[1]++;
                        }
                        if (reservationnformation.get(j).getBookingStatus().equalsIgnoreCase(LessonReservations.ATTEND)) {
                            counter[2]++;
                        }
                        students.put(uniqueCode, counter);
                    }
                }
            }
        }
        
        if(!students.isEmpty()){
            int record =1;
            for (Map.Entry<Integer, int[]> entry : students.entrySet()) {
                int studentUniqueID = entry.getKey();
                int[] counter = entry.getValue();

                //User details
                String studentName = "";
                int studentGrade = 0;
                int age = 0;
                for (int i = 0; i < studentInfo.size(); i++) {
                   if(studentInfo.get(i).getUniqueRollNo() == studentUniqueID){
                       studentName = studentInfo.get(i).getName();
                       studentGrade = studentInfo.get(i).getStudentsGradeLevel();
                       age = studentInfo.get(i).getAge();
                       break;
                   }
                }
                System.out.println("\n\nStudents : "+record);

                System.out.println("\nFirst Name : "+ studentName+"\tCurrent Grade : "+studentGrade+""
                        + "\tAge : "+age+" yrs.\n");
                
                System.out.println("\nNo Of Booked Lessons : "+counter[0]);
                System.out.println("No Of Cancelled Lessons : "+counter[1]);
                System.out.println("No Of Attended Lessons : "+counter[2]);
                
                System.out.println("\nClass Details as follows : ");
                System.out.println("\n------------------------------------------------------------------------------------------------------------------------------------");
                System.out.printf("|%-15s| %-30s| %-12s| %-15s| %-15s| %-15s| %-15s|\n",
                        "LessonsDataID", "Title", "Timing", "Scheduled On","Class Grade","Instructor","Booking Status");
                System.out.println("------------------------------------------------------------------------------------------------------------------------------------");

                for (int j = 0; j < reservationnformation.size(); j++) {
                    if(reservationnformation.get(j).getBookingDoneBy() == studentUniqueID){
                        //Class Detail
                        String title = "";
                        String timing = "";
                        String scheduledOn = "";
                        int instructorUnqiueID = 0;
                        int gradeLevel = 0;
                        for (LessonsData lessonDataObj : lessonInfo) {
                            if(lessonDataObj.getLessonUniqueNo() == reservationnformation.get(j).getBookingFor()){
                                title = lessonDataObj.getTitle();
                                timing = lessonDataObj.getLessonDate();
                                instructorUnqiueID = lessonDataObj.getInstructorUniqueNo();
                                scheduledOn = lessonDataObj.getLessonDate();
                                gradeLevel = lessonDataObj.getLessonGradeLevel();
                                break;
                            }
                        }
                        
                           
                        //Instructor Information
                        String instructorName = "";
                        for(Instructors iObj : instructorsInformation){
                            if(iObj.getUniqueInstructorNo() == instructorUnqiueID ){
                                instructorName = iObj.getName();
                                break;
                            }
                        }

                        System.out.printf("|%-15s| %-30s |%-12s| %-15s| %-15s| %-15s| %-15s|\n",
                        reservationnformation.get(j).getBookingFor(), title, timing, scheduledOn,gradeLevel,
                        instructorName,reservationnformation.get(j).getBookingStatus());
                    }
                }               
                System.out.println("------------------------------------------------------------------------------------------------------------------------------------");
                record++;
            }

        }else{
             System.out.println("No Record Exist");
        }
    }
    
    
    
    private static String getMonthNum(){
        Scanner  sc = new Scanner(System.in);
        System.out.print("\nInput Month Num (1 to 12) : ");
        String month = sc.nextLine();
                
        if(month.equalsIgnoreCase("") || !LessonBookingMainClass.validateInput(month) || (Integer.parseInt(month) < 1 || 
                Integer.parseInt(month) > 12)){
            do{
                System.out.print("\nInput Month Num (1 to 12): ");
                month = sc.nextLine();
            }while(month.equalsIgnoreCase("") || !LessonBookingMainClass.validateInput(month) || (Integer.parseInt(month) < 1
                    || Integer.parseInt(month) > 12));
        }
        return month;
    }
    
}
