
package lessonbooking;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public class Students {
   
    private int uniqueRollNo;
    private String name;
    private int studentLevel;
    private int age;
    private String gender;
    private String phoneNum;
    private String studentPassword;
    
    public static List <Students> studentInformation = new ArrayList<>();

    public Students(int uniqueRollNo, String name, int studentLevel, int age, String gender, String phoneNum, String studentPassword) {
        this.uniqueRollNo = uniqueRollNo;
        this.name = name;
        this.studentLevel = studentLevel;
        this.age = age;
        this.gender = gender;
        this.phoneNum = phoneNum;
        this.studentPassword = studentPassword;
    }

    public int getUniqueRollNo() {
        return uniqueRollNo;
    }

    public String getName() {
        return name;
    }

    public int getStudentsGradeLevel() {
        return studentLevel;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public String getStudentsPassword() {
        return studentPassword;
    }

    public static List<Students> getStudentsInformation() {
        
        Students s1 = new Students(1,"John",1,5,"Male","01527 599995","john123");
        Students s2 = new Students(2,"Alison",2,6,"Male","01745 353978","alison123");
        Students s3 = new Students(3,"Davies",4,9,"Male","01732 751509","davies123");
        Students s4 = new Students(4,"Thompson",3,11,"Male","01793 646600","thompson123");
        Students s5 = new Students(5,"Jones",5,10,"Male","01923 252709","jones123");
        Students s6 = new Students(6,"Evans",0,9,"Male","0191 422 1071","evans123");
        Students s7 = new Students(7,"Helena",1,8,"Female","0113 240 1238","helena123");
        Students s8 = new Students(8,"Stevens",2,6,"Male","01368 862354","stevens123");
        Students s9 = new Students(9,"Ellis",3,4,"Female","0151 705 2222","ellis123");
        Students s10 = new Students(10,"Russell",4,6,"Male","01992 470350","russell123");
        Students s11 = new Students(11,"Butler",5,9,"Male","01383 852737","butler123");
        Students s12 = new Students(12,"Lewis",2,7,"Male","0191 267 6704","lewis123");
        Students s13 = new Students(13,"Alfie",3,6,"Female","01483 224380","alfie123");
        Students s14 = new Students(14,"Adrian",1,8,"Male","0121 742 6068","adrian123");
        Students s15 = new Students(15,"James",4,10,"Male","0151 481 0930","james123");
          
        Students.studentInformation.add(s1);
        Students.studentInformation.add(s2);
        Students.studentInformation.add(s3);
        Students.studentInformation.add(s4);
        Students.studentInformation.add(s5);
        Students.studentInformation.add(s6);
        Students.studentInformation.add(s7);
        Students.studentInformation.add(s8);
        Students.studentInformation.add(s9);
        Students.studentInformation.add(s10);
        Students.studentInformation.add(s11);
        Students.studentInformation.add(s12);
        Students.studentInformation.add(s13);
        Students.studentInformation.add(s14);
        Students.studentInformation.add(s15);
        return studentInformation;
    }

    public void setStudentsGradeLevel(int studentLevel) {
        this.studentLevel = studentLevel;
    }
    
    
    
    //Upadte student grade after attending higher grade level class
    public static void updateStudentsGrade(int studentUniqueID, int lessonselected){
        int studentLevel  = 0;
        int classLevel  = 0;
        //Lesson Grade
        List<LessonsData> lessonInfo = LessonsData.getLessonDataInformation();
         for(LessonsData obj : lessonInfo){
            if(obj.getLessonUniqueNo() == lessonselected){
                classLevel = obj.getLessonGradeLevel();
                break;
            }
        }
         
        //Students current  Grade
        List<Students> studentInformation = Students.getStudentsInformation();
         for(Students obj : studentInformation){
            if(obj.getUniqueRollNo() == studentUniqueID){
                studentLevel = obj.getStudentsGradeLevel();
                break;
            }
        }
       
         //Update current grade level
        if(classLevel > studentLevel){
            for(Students obj : studentInformation){
               if(obj.getUniqueRollNo() == studentUniqueID){
                   obj.setStudentsGradeLevel(obj.getStudentsGradeLevel()+1);
                   break;
               }
           }
        }
    }

    
                    
    //New Student
    public static void registerNewStudent(){
        Scanner sc = new Scanner(System.in);

        System.out.println("\nOnly Students with 4 to 11 yrs are allowed for swimming classes\n");
        
        System.out.print("\nPlease Enter your Name : ");
        String studentName = sc.nextLine();
        
        if(studentName.equalsIgnoreCase("")){
            do{
                System.out.print("\nPlease Enter your Name : ");
                studentName = sc.nextLine();
            }while(studentName.equalsIgnoreCase(""));
        }
        
       
        System.out.print("\nPlease Enter your Password : ");
        String pass = sc.nextLine();
        
        if(pass.equalsIgnoreCase("")){
            do{
                System.out.print("\nPlease Enter your Password : ");
                pass = sc.nextLine();
            }while(pass.equalsIgnoreCase(""));
        }
        
        System.out.print("\nPlease Enter your Phone No : ");
        String phoneNum = sc.nextLine();
        
        if(phoneNum.equalsIgnoreCase("")){
            do{
                System.out.print("\nPlease Enter your Phone No : ");
                phoneNum = sc.nextLine();
            }while(phoneNum.equalsIgnoreCase(""));
        }
        
        System.out.print("\nPlease Enter your Gender (M/F): ");
        String gender = sc.nextLine();
        
        if(gender.equalsIgnoreCase("") || (!gender.equalsIgnoreCase("M") && !gender.equalsIgnoreCase("F"))){
            do{
                System.out.print("\nPlease Enter your Gender (M/F) : ");
                gender = sc.nextLine();
            }while(gender.equalsIgnoreCase("") || (!gender.equalsIgnoreCase("M") && !gender.equalsIgnoreCase("F")));
        }
                
        System.out.print("\nPlease Enter your Age (4-11) : ");
        String age = sc.nextLine();
         
        if(age.equalsIgnoreCase("") || !LessonBookingMainClass.validateInput(age) || Integer.parseInt(age) < 4 || Integer.parseInt(age) >
                11){
            do{
                System.out.print("\nPlease Enter your Age (4-11) : ");
                age = sc.nextLine();
            }while(age.equalsIgnoreCase("") || !LessonBookingMainClass.validateInput(age) || Integer.parseInt(age) < 4 || 
                    Integer.parseInt(age) > 11);
        }
    

        System.out.print("\nPlease Enter your Grade Level ("+1+" TO "+ 5+") : ");
        String grade = sc.nextLine();
        
         
        if(grade.equalsIgnoreCase("") || !LessonBookingMainClass.validateInput(grade) || (Integer.parseInt(grade) < 1 || Integer.parseInt(grade) > 5)){
            do{
                System.out.print("\nPlease Enter your Grade Level ("+1+" TO "+ 5+") : ");
                grade = sc.nextLine();
            }while(grade.equalsIgnoreCase("") || !LessonBookingMainClass.validateInput(grade) || (Integer.parseInt(grade) < 1 || Integer.parseInt(grade) > 5));
        }
    
        Random random = new Random();
        int studentUniqueNo = random.nextInt(90) + 10; 
       
        //Add Obj to ArrayList
        Students obj = new Students(studentUniqueNo,studentName,Integer.parseInt(grade),Integer.parseInt(age),
                gender,phoneNum,pass);
        Students.studentInformation.add(obj);
        System.out.println("\nStudent registered with the system Successfully! Your Unique ID For SignIn Process : "+studentUniqueNo);
        
    }
    

    //Student Dashboard Menu
    public static void studentDashboardMenu(){     
        int selectedOption;
        do {
            selectedOption = studentOptions();
            switch (selectedOption) {
                case 1 -> LessonsData.filterOnLessonsMenu();
                case 2 -> {
                            LessonReservations.IS_BOOKING = 1;
                            LessonsData.filterOnLessonsMenu();
                        }
                case 3 -> {
                            LessonReservations.IS_CHANGING = 1;
                            LessonReservations.change();
                          }
                case 4 -> Feedbacks.attend();
                case 5 -> LessonReservations.cancel();
                case 6 -> LessonReservations.view();
                case 7 -> {
                            SignedInUser.STUDENT_UNIQUE_ROLL_NO = 0;
                            LessonReservations.CHANGING_BOOKING_ID= 0;
                            LessonReservations.IS_BOOKING = 0;
                            LessonReservations.IS_CHANGING = 0;
                            return;
                        }
                default -> System.out.println("\nPlease enter a valid choice (1-7)");
            }
        } while (selectedOption != 7);
    }

    
    //Student Functions Options
    public static int studentOptions(){     
        Scanner sc = new Scanner(System.in);

        System.out.println("\n\nSelect your choice : ");
        System.out.println("1. Check Timetable");
        System.out.println("2. Reserve New Lesson");
        System.out.println("3. Update Reserved Lesson");
        System.out.println("4. Attend Reserved Lesson");
        System.out.println("5. Cancel Reserved Lesson");
        System.out.println("6. All Reservations");
        System.out.println("7. Sign out");
        System.out.print("\nEnter Your Choice : ");

        String menuOption = sc.nextLine();
        while (menuOption.equals("") || !LessonBookingMainClass.validateInput(menuOption))
        {
            System.out.print("\nYour Choice is not valid. Please Enter again your choice : ");
            menuOption = sc.nextLine();
        }
        return Integer.parseInt(menuOption);
    }
 
    
    //view registered students
    public static void viewAllStudents(){
        System.out.println("\n\n-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("| %-15s | %-15s | %-15s | %-10s | %-10s | %-15s | \n",
                "UniqueNo","Student Name", "StudentGrade","Age", "Gender", "PhoneNo");
        System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        Set<String> uniqueRecords = new HashSet<>(); 
        List<Students> studentInfo = Students.getStudentsInformation();
        for(Students obj : studentInfo){
            if (!uniqueRecords.contains(String.valueOf(obj.getUniqueRollNo()))){
                uniqueRecords.add(String.valueOf(obj.getUniqueRollNo()));     

                System.out.printf("| %-15s | %-15s | %-15s | %-10s | %-10s | %-15s | \n",
                     obj.getUniqueRollNo(),obj.getName(), obj.getStudentsGradeLevel(),obj.getAge()+" yrs.", obj.getGender(),
                     obj.getPhoneNum());
            }
        }
        System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

    }
    
    
    //Update student grade after attending class
    public static void incStudentGrade(int studentUniqueID, int lessonSelected){
        int studentLevel  = 0;
        int classLevel  = 0;
        //Class Grade
        List<LessonsData> lessonInfo = LessonsData.getLessonDataInformation();
         for(LessonsData obj : lessonInfo){
            if(obj.getLessonUniqueNo() == lessonSelected){
                classLevel = obj.getLessonGradeLevel();
                break;
            }
        }
         
        //Student current  Grade
        List<Students> studentInfo = Students.getStudentsInformation();
         for(Students obj : studentInfo){
            if(obj.getUniqueRollNo() == studentUniqueID){
                studentLevel = obj.getStudentsGradeLevel();
                break;
            }
        }
       
         //Update grade level
        if(classLevel > studentLevel){
            for(Students obj : studentInfo){
                if(obj.getUniqueRollNo() == studentUniqueID){
                   obj.setStudentsGradeLevel(obj.getStudentsGradeLevel()+1);
                   break;
               }
           }
        }
    }

    
}
