
package lessonbooking;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;


public class Feedbacks {
    
    private int reservationNo;
    private int submittedBy;
    private int submittedFor;
    private int rating;
    private String feedback;
    
    public static List <Feedbacks> feedbackInformation = new ArrayList<>();

    public Feedbacks(int reservationNo, int submittedBy, int submittedFor, int rating, String feedback) {
        this.reservationNo = reservationNo;
        this.submittedBy = submittedBy;
        this.submittedFor = submittedFor;
        this.rating = rating;
        this.feedback = feedback;
    }

    public int getBookingNo() {
        return reservationNo;
    }

    public int getSubmittedBy() {
        return submittedBy;
    }

    public int getSubmittedFor() {
        return submittedFor;
    }

    public int getRating() {
        return rating;
    }

    public String getFeedback() {
        return feedback;
    }

    public static List<Feedbacks> getFeedbackInformation() {
        return feedbackInformation;
    }

        
    //Attend class
    public static void attend(){
        Scanner sc = new Scanner(System.in);
        
        //Take Lesson Choice
        System.out.print("\nEnter Booking ID for which you want to attend lesson : ");
        String bookingID = sc.nextLine();
        int reservationNo = Integer.parseInt(bookingID);
        
        //Validate Booking ID
        boolean validateBookingID = LessonReservations.checkReservationID(reservationNo);
        if(!validateBookingID){
            System.out.println("\nYou have entered incorrect Booking ID.");
            return;
        }
                
        int instructorUnqID = 0;
        int lessonUniqueID = 0;
        List<LessonReservations> reservationInformation = LessonReservations.getReservationInformation();
        List<LessonsData> lessonsDataInformation = LessonsData.getLessonDataInformation();
        List<Instructors> instructorsInformation = Instructors.getInstructorInformation();
        
        if(reservationInformation.size() < 1){
            System.out.println("\nNo Reservation exists"); 
            return;
        }
        
        for(LessonReservations obj : reservationInformation){
            if(obj.getBookingNo() == reservationNo){
                for(LessonsData lessondataObj : lessonsDataInformation){
                    if(obj.getBookingFor() == lessondataObj.getLessonUniqueNo()){
                        instructorUnqID = lessondataObj.getInstructorUniqueNo();
                        lessonUniqueID = lessondataObj.getLessonUniqueNo();
                        break;
                    }
                }
            }
        }
        
        //Instructor Information
        String instructorName = "";
        for(Instructors iObj : instructorsInformation){
            if(iObj.getUniqueInstructorNo() == instructorUnqID ){
                instructorName = iObj.getName();
                break;
            }
        }
            
        //Is Already cancelled or attended
        boolean validateBookingStatus = LessonReservations.checkReservationStatus(reservationNo);
        if(validateBookingStatus){
            System.out.println("\nYou have already attended or cancelled given Booking ID");
            return;
        }
        
        System.out.print("\nPlease Write a Feedback for instructor "+instructorName+" : ");
        String feedbackForInstructor = sc.nextLine();
        
        if(feedbackForInstructor.equalsIgnoreCase("")){
            do{
                System.out.print("\nPlease Write a Feedback for instructor "+instructorName+" : ");
                feedbackForInstructor = sc.nextLine();
            }while(feedbackForInstructor.equalsIgnoreCase(""));
        }
        
        System.out.println("\n\n------------------------------------------");
        System.out.printf("| %-15s | %-20s |\n","Rating Value","Feedback");
        System.out.println("------------------------------------------");
        System.out.printf("| %-15s | %-20s |\n","1","Very dissatisfied");
        System.out.printf("| %-15s | %-20s |\n","2","Dissatisfied");
        System.out.printf("| %-15s | %-20s |\n","3","OK");
        System.out.printf("| %-15s | %-20s |\n","4","Satisfied");
        System.out.printf("| %-15s | %-20s |\n","5","Very Satisfied");
        System.out.println("------------------------------------------");
        
        System.out.print("\nPlease Enter Rating to give it to your instructor "+instructorName+" : ");
        String rating = sc.nextLine();
         
        if(rating.equalsIgnoreCase("") || !LessonBookingMainClass.validateInput(rating) || Integer.parseInt(rating) < 1 || Integer.parseInt(rating) > 5){
            do{
                System.out.print("\nPlease Enter Rating to give it to your instructor "+instructorName+" : ");
                rating = sc.nextLine();
            }while(rating.equalsIgnoreCase("") || !LessonBookingMainClass.validateInput(rating) || Integer.parseInt(rating) < 1 || Integer.parseInt(rating) > 5);
        }
    
        //Add Feedback
        Feedbacks obj = new Feedbacks(reservationNo,SignedInUser.STUDENT_UNIQUE_ROLL_NO,lessonUniqueID,Integer.parseInt(rating),feedbackForInstructor);
        Feedbacks.feedbackInformation.add(obj);
        
        //Update status
        for(LessonReservations obj1 : reservationInformation){
            if(obj1.getBookingNo() == reservationNo){
                obj1.setBookingStatus(LessonReservations.ATTEND);
                break;
            }
        }
        
        //Update available seats by increasing by 1
        LessonsData.setSeats(lessonUniqueID,0,1);
        
        //Update grade of student if attended higher grade class
        Students.incStudentGrade(SignedInUser.STUDENT_UNIQUE_ROLL_NO,lessonUniqueID);
        
        System.out.println("\nYour feedback is submitted!");
        return;
        
    }
    
    
     
    //View Ratings
    public static void viewRatings(){
        
        List<Feedbacks> feedbackForInstructorInfo = Feedbacks.getFeedbackInformation();
        List<LessonReservations> reservationInformation = LessonReservations.getReservationInformation();
        List<LessonsData> lessonsDataInformation = LessonsData.getLessonDataInformation();
        List<Students> studentInfo = Students.getStudentsInformation();
        List<Instructors> instructorsInformation = Instructors.getInstructorInformation();

                
        if(feedbackForInstructorInfo.size() < 1){
            System.out.println("\nNo Review Found"); 
            return;
        }

        System.out.println("\n\n--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("| %-12s | %-18s | %-13s | %-40s | %-15s | %-10s | %-30s \n",
                "ReservationNo","SubmittedBy", "LessonsDataID", "Title", "SubmittedFor","Rating","Feedbacks");
        System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        
        Set<String> uniqueRecords = new HashSet<>(); 

        for(Feedbacks feedbackForInstructorObj : feedbackForInstructorInfo){
            for(LessonReservations obj : reservationInformation){
                
                if(feedbackForInstructorObj.getBookingNo() == obj.getBookingNo()){
                    
                    //Lesson Details
                    String title = "";
                    int instructorUniqueID = 0;
                    for(LessonsData lessondataObj : lessonsDataInformation){
                        if(obj.getBookingFor() == lessondataObj.getLessonUniqueNo()){
                            title = lessondataObj.getTitle();
                            instructorUniqueID = lessondataObj.getInstructorUniqueNo();
                            break;
                        }
                    }
                    
                    //Student Details
                    String studentName = "";
                    for(Students studentObj : studentInfo){
                        if(studentObj.getUniqueRollNo() == obj.getBookingDoneBy()){
                            studentName = studentObj.getName();
                            break;
                        }
                    }
                    
                    
                      
                    //Instructor Information
                    String instructorName = "";
                    for(Instructors iObj : instructorsInformation){
                        if(iObj.getUniqueInstructorNo() == instructorUniqueID ){
                            instructorName = iObj.getName();
                            break;
                        }
                    }

                    //Display
                    if (!uniqueRecords.contains(String.valueOf(feedbackForInstructorObj.getBookingNo()))){
                        uniqueRecords.add(String.valueOf(feedbackForInstructorObj.getBookingNo()));     

                         System.out.printf("| %-12s | %-18s | %-13s | %-40s | %-15s | %-10s | %-30s \n",
                        feedbackForInstructorObj.getBookingNo(),studentName, obj.getBookingFor(), title, instructorName,
                        feedbackForInstructorObj.getRating(),
                        feedbackForInstructorObj.getFeedback());
                    }
                }
            }
        }
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

    }
    
    
    
}
