
package lessonbooking;

import java.util.List;
import java.util.Scanner;


public class LessonBookingMainClass {

    public static void main(String[] args) {
        System.out.println("\n---------------------------------------------------------- ");
        System.out.println("The Hatfield Junior Swimming School Software ");
        System.out.println("---------------------------------------------------------- \n");
        int selectedOption;
        do {
            selectedOption = mainMenu();
            switch (selectedOption) {
                case 1 -> Students.registerNewStudent();
                case 2 -> signInToSystem();
                case 3 ->{
                             System.out.println("\nThe Hatfield Junior Swimming School Software exits\n\n");
                             System.exit(0);
                        }
                default -> System.out.println("\nPlease enter a valid choice (1-3)");
            }
        } while (selectedOption != 3);
    }
    
    
    //Main Menu
    public static int mainMenu(){     
        Scanner sc = new Scanner(System.in);

        System.out.println("\n\nSelect your choice : ");
        System.out.println("1. Create an Account with us");
        System.out.println("2. SignIn to the System");
        System.out.println("3. Exit");
        System.out.print("\nEnter Your Choice : ");

        String menuOption = sc.nextLine();
        while (menuOption.equals("") || !validateInput(menuOption))
        {
            System.out.print("\nYour Choice is not valid. Please Enter again your choice : ");
            menuOption = sc.nextLine();
        }
        return Integer.parseInt(menuOption);
    }
 
    
    //Check choice 
    public static boolean validateInput(String choice)
    {
        if (choice == null || choice.isEmpty()) {
             return false;
         }
         for (int i = 0; i < choice.length(); i++) {
             if (!Character.isDigit(choice.charAt(i))) {
                 return false;
             }
         }
         return true;
    }
     
    
    //SignIn to system
    public static void signInToSystem()
    {                
        boolean isDirector = false;
        boolean isStudent = false;
        
        Scanner sc = new Scanner(System.in);
        System.out.print("\nEnter ID : ");
        String studentUniqueID = sc.nextLine();
        
        if(studentUniqueID.equalsIgnoreCase("") || !validateInput(studentUniqueID)){
            do{
                System.out.print("\nEnter ID : ");
                studentUniqueID = sc.nextLine();
            }while(studentUniqueID.equalsIgnoreCase("") || !validateInput(studentUniqueID));
        }
        
        System.out.print("\nEnter Password : ");
        String password = sc.nextLine();
        
        if(password.equalsIgnoreCase("")){
            do{
                System.out.print("\nYou can't skip Password. Please Enter : ");
                password = sc.nextLine();
            }while(password.equalsIgnoreCase(""));
        }
        
        List<Students> studentInformation = Students.getStudentsInformation();
        List<ManagingDirector> directorInformation = ManagingDirector.getDirectorInformation();
        
        for(Students obj : studentInformation){
            if(obj.getUniqueRollNo() == Integer.parseInt(studentUniqueID) && obj.getStudentsPassword().equalsIgnoreCase(password)){
                SignedInUser.STUDENT_UNIQUE_ROLL_NO = obj.getUniqueRollNo();
                isStudent = true;

                System.out.println("\n================================");
                System.out.println("Signed In Successful");
                System.out.println("Your Student Grade Level is : "+obj.getStudentsGradeLevel());
                System.out.println("================================");
                Students.studentDashboardMenu();
                return;
            }
        }
        for(ManagingDirector obj : directorInformation){
            if(obj.getUniqueManagerNo() == Integer.parseInt(studentUniqueID) && obj.getPasssword().equalsIgnoreCase(password)){
                SignedInUser.DIRECTOR_ID = obj.getUniqueManagerNo();
                isDirector = true;
                System.out.println("\n================================");
                System.out.println("Signed In Successful");
                System.out.println("================================");
                ManagingDirector.directorDashbboardOptions();
                return;
            }
        }
        if(!isDirector && !isStudent){
            System.out.println("\nCredentials are wrong");
            return;
        }
    }

  
    
}
