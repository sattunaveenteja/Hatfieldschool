
package lessonbooking;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class ManagingDirector {
    
    private int uniqueManagerNo;
    private String name;
    private String phoneNum;
    private String passsword;
    
    public static List <ManagingDirector> directorInformation = new ArrayList<>();

    public ManagingDirector(int uniqueManagerNo, String name, String phoneNum, String passsword) {
        this.uniqueManagerNo = uniqueManagerNo;
        this.name = name;
        this.phoneNum = phoneNum;
        this.passsword = passsword;
    }

    public int getUniqueManagerNo() {
        return uniqueManagerNo;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public String getPasssword() {
        return passsword;
    }

    public static List<ManagingDirector> getDirectorInformation() {
        ManagingDirector d1 = new ManagingDirector(1,"Director","0121 789 8405","director11");
        ManagingDirector.directorInformation.add(d1);
        return directorInformation;
    }
    

    //Managing Director Menu
    public static void directorDashbboardOptions(){     
        int selectedOption;
        do {
            selectedOption = directorOptions();
            switch (selectedOption) {
                case 1 -> LessonsData.filterOnLessonsMenu();
                case 2 -> Students.viewAllStudents();
                case 3 -> LessonReservations.view();
                case 4 -> Feedbacks.viewRatings();
                case 5 -> {
                            StudentReport studentReport = new StudentReport();
                            // Create invoker
                            InvokerClass invoker = new InvokerClass();
                            invoker.setCommand(studentReport);
                            invoker.displayReport();
                          }
                case 6 -> {
                            InstructorReport instructorReport = new InstructorReport();
                            // Create invoker
                            InvokerClass invoker = new InvokerClass();
                            invoker.setCommand(instructorReport);
                            invoker.displayReport();
                            
                        }
                case 7 -> {
                            SignedInUser.DIRECTOR_ID = 0;
                            return;
                        }
                default -> System.out.println("\nPlease enter a valid choice (1-7)");
            }
        } while (selectedOption != 7);
    }


    
    //Director Options
    public static int directorOptions(){     
        Scanner sc = new Scanner(System.in);

        System.out.println("\n\nSelect your choice : ");
        System.out.println("1. Check Timetable");
        System.out.println("2. All Students");
        System.out.println("3. All Reservations");
        System.out.println("4. All Feedbacks");
        System.out.println("5. Student Report");
        System.out.println("6. Instructor Report");
        System.out.println("7. Sign Out");
        System.out.print("\nEnter Your Choice : ");

        String menuOption = sc.nextLine();
        while (menuOption.equals("") || !LessonBookingMainClass.validateInput(menuOption))
        {
            System.out.print("\nYour Choice is not valid. Please Enter again your choice : ");
            menuOption = sc.nextLine();
        }
        return Integer.parseInt(menuOption);
    }
 
    
    
}
