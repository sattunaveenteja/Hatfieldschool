
package lessonbooking;

public interface CommandInterface {
    
      void generate();
}
