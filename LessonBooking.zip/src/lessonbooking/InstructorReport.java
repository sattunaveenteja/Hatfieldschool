
package lessonbooking;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;


public class InstructorReport implements CommandInterface{
    
    @Override
    public void generate() {
       
        String  month = getMonthNum();
        List<Feedbacks> feedbacksInformation = Feedbacks.getFeedbackInformation();
        List<LessonsData> lessonInfo = LessonsData.getLessonDataInformation();
        List<LessonReservations> reservationnformation = LessonReservations.getReservationInformation();
        List<Instructors> instructorsInformation = Instructors.getInstructorInformation();

        HashMap<String, Integer> feedbacks = new HashMap<>();
        HashMap<String, Integer> noOfRows = new HashMap<>();
        HashMap<String, Double> calculate = new HashMap<>();
       
        System.out.println();
       
        for (Feedbacks obj : feedbacksInformation){
            
            int lessonUniqueID =0;
            
            for(LessonReservations reservationObj : reservationnformation){
                if(reservationObj.getBookingNo() == obj.getBookingNo()){
                    lessonUniqueID = reservationObj.getBookingFor();
                    break;
                }
            }
            for (LessonsData lessonObj : lessonInfo){
                
                 //Parse class lesson scheduled date
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");                
                
                String lessonMonth = "";
                try {
                    LocalDateTime parsedDateTime = LocalDate.parse(lessonObj.getLessonDate(), formatter).atStartOfDay();
                    lessonMonth = parsedDateTime.format(DateTimeFormatter.ofPattern("M"));
                } catch (DateTimeParseException e) {
                    System.out.println("Error parsing datetime: " + e.getMessage());
                }
                    
                
                if(lessonObj.getLessonUniqueNo() == lessonUniqueID && lessonMonth.equalsIgnoreCase(month)){
                    int instructorUniqueID = lessonObj.getInstructorUniqueNo();
                    
                     //Instructor Information
                        String instructorName = "";
                        for(Instructors iObj : instructorsInformation){
                            if(iObj.getUniqueInstructorNo() == instructorUniqueID ){
                                instructorName = iObj.getName();
                                break;
                            }
                        }
            
                    int plusRating = obj.getRating();
                    
                    feedbacks.put(instructorName, feedbacks.getOrDefault(instructorName, 0) + plusRating);
                    noOfRows.put(instructorName, noOfRows.getOrDefault(instructorName, 0) + 1);
                }
            }
        }

        for (String instructor : feedbacks.keySet()) {
            int calculateRating = feedbacks.get(instructor);
            int totalNumOfRating = noOfRows.get(instructor);

            if (totalNumOfRating > 0) {
                double avg = (double) calculateRating / totalNumOfRating;
                double ans = Math.round(avg * 10.0) / 10.0; 
                calculate.put(instructor, ans);
            }
        }
        if(!calculate.isEmpty()){
            System.out.println("\n--------------------------------------");
            System.out.printf("|%-15s |%-20s| \n", "Instructor Name", "Average Rating");
            System.out.println("--------------------------------------");
            for (String instructor : calculate.keySet()) {
                double averageRating = calculate.get(instructor);
                System.out.printf("|%-15s| %-20s| \n", instructor, averageRating);
            }
            System.out.println("--------------------------------------");
        }else{
            System.out.println("No Record Exist");
        }
    }
    
    
    private static String getMonthNum(){
        Scanner  sc = new Scanner(System.in);
        System.out.print("\nInput Month Num (1 to 12) : ");
        String month = sc.nextLine();
                
        if(month.equalsIgnoreCase("") || !LessonBookingMainClass.validateInput(month) || (Integer.parseInt(month) < 1 || 
                Integer.parseInt(month) > 12)){
            do{
                System.out.print("\nInput Month Num (1 to 12): ");
                month = sc.nextLine();
            }while(month.equalsIgnoreCase("") || !LessonBookingMainClass.validateInput(month) || (Integer.parseInt(month) < 1
                    || Integer.parseInt(month) > 12));
        }
        return month;
    }
    
}
