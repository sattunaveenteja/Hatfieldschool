
package lessonbooking;


public class SignedInUser {
    
    public static int STUDENT_UNIQUE_ROLL_NO = 0;
    public static int DIRECTOR_ID = 0;
}
