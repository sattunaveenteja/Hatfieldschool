
package lessonbooking;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;


public class LessonsData {
 
    private int lessonUniqueNo;
    private String title;
    private String dayName;
    private String lessonTime;
    private String lessonDate;
    private int instructorUniqueNo;
    private int availableSeats;
    private int classLevel;
    
    private static final int FILTER_BY_DAY = 1;
    private static final int FILTER_BY_INSTRUCTOR = 2;
    private static final int FILTER_BY_GRADE_LEVEL = 3;
    private static final int AVAILABLE_SEATS = 4;
    
    public static List <LessonsData> lessonDataInformation = new ArrayList<>();

    public LessonsData(int lessonUniqueNo, String title, String dayName, String lessonTime, String lessonDate, int instructorUniqueNo,
            int availableSeats, int classLevel) {
        this.lessonUniqueNo = lessonUniqueNo;
        this.title = title;
        this.dayName = dayName;
        this.lessonTime = lessonTime;
        this.lessonDate = lessonDate;
        this.instructorUniqueNo = instructorUniqueNo;
        this.availableSeats = availableSeats;
        this.classLevel = classLevel;
    }
    
    public int getLessonUniqueNo() {
        return lessonUniqueNo;
    }

    public String getTitle() {
        return title;
    }

    public String getDayName() {
        return dayName;
    }

    public String getLessonTime() {
        return lessonTime;
    }

    public String getLessonDate() {
        return lessonDate;
    }

    public int getInstructorUniqueNo() {
        return instructorUniqueNo;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public int getLessonGradeLevel() {
        return classLevel;
    }

    public static List<LessonsData> getLessonDataInformation() {
        LessonsData l1 = new LessonsData(1,"Safe entry and exit","mon","4 to 5pm","01-04-2024",1,
                AVAILABLE_SEATS,4);
        LessonsData l2 = new LessonsData(2,"Submerging","mon","5 to 6pm","01-04-2024",2,
                AVAILABLE_SEATS,2);
        LessonsData l3 = new LessonsData(3,"Buoyancy","mon","6 to 7pm","01-04-2024",3,
                AVAILABLE_SEATS,1);
        
        
        LessonsData l4 = new LessonsData(4,"Changing body position","wed","4 to 5pm","03-04-2024",4,
                AVAILABLE_SEATS,5);
        LessonsData l5 = new LessonsData(5,"Water safety skills","wed","5 to 6pm","03-04-2024",2,
                AVAILABLE_SEATS,3);
        LessonsData l6 = new LessonsData(6,"Floating Skills","wed","6 to 7pm","03-04-2024",1,
                AVAILABLE_SEATS,1);
        
        
        LessonsData l7 = new LessonsData(7,"Arm and leg strokes","fri","4 to 5pm","05-04-2024",3,
                AVAILABLE_SEATS,2);
        LessonsData l8 = new LessonsData(8,"Assisted skills","fri","5 to 6pm","05-04-2024",4,
                AVAILABLE_SEATS,1);
        LessonsData l9 = new LessonsData(9,"Front and back crawl","fri","6 to 7pm","05-04-2024",2,
                AVAILABLE_SEATS,4);
        

        LessonsData l10 = new LessonsData(10,"Stroke development","sat","2 to 3pm","06-04-2024",1,
                AVAILABLE_SEATS,2);
        LessonsData l11 = new LessonsData(11,"Breaststroke","sat","3 to 4pm","06-04-2024",3,
                AVAILABLE_SEATS,1);
        
        
        LessonsData l12 = new LessonsData(12,"Individual medley","mon","4 to 5pm","08-04-2024",1,
                AVAILABLE_SEATS,4);
        LessonsData l13 = new LessonsData(13,"Stroke refinement","mon","5 to 6pm","08-04-2024",2,
                AVAILABLE_SEATS,2);
        LessonsData l14 = new LessonsData(14,"Coordination and efficiency","mon","6 to 7pm","08-04-2024",3,
                AVAILABLE_SEATS,1);
        
        
        LessonsData l15 = new LessonsData(15,"Flip turns","wed","4 to 5pm","10-04-2024",4,
                AVAILABLE_SEATS,5);
        LessonsData l16 = new LessonsData(16,"Water safety","wed","5 to 6pm","10-04-2024",2,
                AVAILABLE_SEATS,3);
        LessonsData l17 = new LessonsData(17,"Fitness swimming","wed","6 to 7pm","10-04-2024",1,
                AVAILABLE_SEATS,1);
        
        
        LessonsData l18 = new LessonsData(18,"Building endurance","fri","4 to 5pm","12-04-2024",3,
                AVAILABLE_SEATS,2);
        LessonsData l19 = new LessonsData(19,"Strokes","fri","5 to 6pm","12-04-2024",4,
                AVAILABLE_SEATS,1);
        LessonsData l20 = new LessonsData(20,"Fine-tuning strokes","fri","6 to 7pm","12-04-2024",2,
                AVAILABLE_SEATS,4);
        

        LessonsData l21 = new LessonsData(21,"Introducing backstroke","sat","2 to 3pm","13-04-2024",1,
                AVAILABLE_SEATS,2);
        LessonsData l22 = new LessonsData(22,"Backstroke","sat","3 to 4pm","13-04-2024",3,
                AVAILABLE_SEATS,1);

        
        LessonsData l23 = new LessonsData(23,"Safe entry and exit","mon","4 to 5pm","15-04-2024",1,
                AVAILABLE_SEATS,4);
        LessonsData l24 = new LessonsData(24,"Assisted skills","mon","5 to 6pm","15-04-2024",2,
                AVAILABLE_SEATS,2);
        LessonsData l25 = new LessonsData(25,"Water safety skills","mon","6 to 7pm","15-04-2024",3,
                AVAILABLE_SEATS,1);
        
        
        LessonsData l26 = new LessonsData(26,"Front and back crawl","wed","4 to 5pm","17-04-2024",4,
                AVAILABLE_SEATS,5);
        LessonsData l27 = new LessonsData(27,"Submerging","wed","5 to 6pm","17-04-2024",2,
                AVAILABLE_SEATS,3);
        LessonsData l28 = new LessonsData(28,"Arm and leg strokes","wed","6 to 7pm","17-04-2024",1,
                AVAILABLE_SEATS,1);
        
        
        LessonsData l29 = new LessonsData(29,"Water safety skills","fri","4 to 5pm","19-04-2024",3,
                AVAILABLE_SEATS,2);
        LessonsData l30 = new LessonsData(30,"Breaststroke","fri","5 to 6pm","19-04-2024",4,
                AVAILABLE_SEATS,1);
        LessonsData l31 = new LessonsData(31,"Flip turns","fri","6 to 7pm","19-04-2024",2,
                AVAILABLE_SEATS,4);
        

        LessonsData l32 = new LessonsData(32,"Fitness swimming","sat","2 to 3pm","20-04-2024",1,
                AVAILABLE_SEATS,2);
        LessonsData l33 = new LessonsData(33,"Individual medley","sat","3 to 4pm","20-04-2024",3,
                AVAILABLE_SEATS,1);
        
        
        LessonsData l34 = new LessonsData(34,"Stroke refinement","mon","4 to 5pm","22-04-2024",1,
                AVAILABLE_SEATS,4);
        LessonsData l35 = new LessonsData(35,"Backstroke","mon","5 to 6pm","22-04-2024",2,
                AVAILABLE_SEATS,2);
        LessonsData l36 = new LessonsData(36,"Stroke refinement","mon","6 to 7pm","22-04-2024",3,
                AVAILABLE_SEATS,1);
        
        
        LessonsData l37 = new LessonsData(37,"Introducing backstroke","wed","4 to 5pm","24-04-2024",4,
                AVAILABLE_SEATS,5);
        LessonsData l38 = new LessonsData(38,"Flip turns","wed","5 to 6pm","24-04-2024",2,
                AVAILABLE_SEATS,3);
        LessonsData l39 = new LessonsData(39,"Floating Skills","wed","6 to 7pm","24-04-2024",1,
                AVAILABLE_SEATS,1);
        
        
        LessonsData l40 = new LessonsData(40,"Backstroke","fri","4 to 5pm","26-04-2024",3,
                AVAILABLE_SEATS,2);
        LessonsData l41 = new LessonsData(41,"Fitness swimming","fri","5 to 6pm","26-04-2024",4,
                AVAILABLE_SEATS,1);
        LessonsData l42 = new LessonsData(42,"Front and back crawl","fri","6 to 7pm","26-04-2024",2,
                AVAILABLE_SEATS,4);
        

        LessonsData l43 = new LessonsData(43,"Fine-tuning strokes","sat","2 to 3pm","27-04-2024",1,
                AVAILABLE_SEATS,2);
        LessonsData l44 = new LessonsData(44,"Breaststroke","sat","3 to 4pm","27-04-2024",3,
                AVAILABLE_SEATS,1);
        
        
        LessonsData.lessonDataInformation.add(l1);
        LessonsData.lessonDataInformation.add(l2);
        LessonsData.lessonDataInformation.add(l3);
        LessonsData.lessonDataInformation.add(l4);
        LessonsData.lessonDataInformation.add(l5);
        LessonsData.lessonDataInformation.add(l6);
        LessonsData.lessonDataInformation.add(l7);
        LessonsData.lessonDataInformation.add(l8);
        LessonsData.lessonDataInformation.add(l9);
        LessonsData.lessonDataInformation.add(l10);
        LessonsData.lessonDataInformation.add(l11);
        LessonsData.lessonDataInformation.add(l12);
        LessonsData.lessonDataInformation.add(l13);
        LessonsData.lessonDataInformation.add(l14);
        LessonsData.lessonDataInformation.add(l15);
        LessonsData.lessonDataInformation.add(l16);
        LessonsData.lessonDataInformation.add(l17);
        LessonsData.lessonDataInformation.add(l18);
        LessonsData.lessonDataInformation.add(l19);
        LessonsData.lessonDataInformation.add(l20);
        LessonsData.lessonDataInformation.add(l21);
        LessonsData.lessonDataInformation.add(l22);
        LessonsData.lessonDataInformation.add(l23);
        LessonsData.lessonDataInformation.add(l24);
        LessonsData.lessonDataInformation.add(l25);
        LessonsData.lessonDataInformation.add(l26);
        LessonsData.lessonDataInformation.add(l27);
        LessonsData.lessonDataInformation.add(l28);
        LessonsData.lessonDataInformation.add(l29);
        LessonsData.lessonDataInformation.add(l30);
        LessonsData.lessonDataInformation.add(l31);
        LessonsData.lessonDataInformation.add(l32);
        LessonsData.lessonDataInformation.add(l33);
        LessonsData.lessonDataInformation.add(l34);
        LessonsData.lessonDataInformation.add(l35);
        LessonsData.lessonDataInformation.add(l36);
        LessonsData.lessonDataInformation.add(l37);
        LessonsData.lessonDataInformation.add(l38);
        LessonsData.lessonDataInformation.add(l39);
        LessonsData.lessonDataInformation.add(l40);
        LessonsData.lessonDataInformation.add(l41);
        LessonsData.lessonDataInformation.add(l42);
        LessonsData.lessonDataInformation.add(l43);
        LessonsData.lessonDataInformation.add(l44);
        
        return lessonDataInformation;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }

    
    
    //View Scheduled Classes
    public static void filterOnLessonsMenu(){
        System.out.println("\nEnter 1 for Filter By Day");
        System.out.println("Enter 2 Filter By Instructor");
        System.out.println("Enter 3 to Filter By Grade Level");
        System.out.println("Enter 4 to Go Back To Main Menu");
        
        Scanner sc = new Scanner(System.in);
        System.out.print("\nPlease Enter your Choice : ");
        String choice = sc.nextLine();
        
        //Validations
        if(choice.equalsIgnoreCase("")){
           do{
                System.out.print("\nPlease Enter your Choice : ");
                choice = sc.nextLine();
            }while(choice.equalsIgnoreCase("")); 
        }
        
        if(choice.equalsIgnoreCase("4")){
           return;
        }
        
        if(choice.equalsIgnoreCase("") || !(choice.equalsIgnoreCase("1") || choice.equalsIgnoreCase("2") ||
                 choice.equalsIgnoreCase("3"))){
            do{
                System.out.print("\nPlease Enter your Choice : ");
                choice = sc.nextLine();
            }while(choice.equalsIgnoreCase("") || !(choice.equalsIgnoreCase("1") || choice.equalsIgnoreCase("2") ||
                 choice.equalsIgnoreCase("3")));
        }
        
        switch (Integer.parseInt(choice)) {
            case FILTER_BY_DAY:
                System.out.print("Please Enter Day (Mon/Wed/Fri/Sat) : ");
                String day = sc.nextLine();
                if(day.equalsIgnoreCase("")){
                    do{
                        System.out.print("\nPlease Enter Day (Mon/Wed/Fri/Sat) : ");
                        day = sc.nextLine();
                    }while(day.equalsIgnoreCase(""));
                }   if(day.equalsIgnoreCase("Monday")){
                    day = "Mon";
                }else if(day.equalsIgnoreCase("Wednesday")){
                    day = "Wed";
                }else if(day.equalsIgnoreCase("Friday")){
                    day = "Fri";
                }else if(day.equalsIgnoreCase("Saturday")){
                    day = "Sat";
                }   if(!(day.equalsIgnoreCase("Mon") || day.equalsIgnoreCase("Wed") || day.equalsIgnoreCase("Fri") ||
                        day.equalsIgnoreCase("Sat"))){
                    do{
                        System.out.print("\nPlease Enter Day (Mon/Wed/Fri/Sat) : ");
                        day = sc.nextLine();
                    }while(!(day.equalsIgnoreCase("Mon") || day.equalsIgnoreCase("Wed") || day.equalsIgnoreCase("Fri") ||
                            day.equalsIgnoreCase("Sat")));
                }   viewLessons(day,"","");
                break;
            case FILTER_BY_GRADE_LEVEL:
                System.out.println("\n(1 to 5)");
                System.out.print("Please Enter Grade Level (1-5) : ");
                String givenGrade = sc.nextLine();
                if(givenGrade.equalsIgnoreCase("") || !LessonBookingMainClass.validateInput(givenGrade) || (Integer.parseInt(givenGrade) < 0 || Integer.parseInt(givenGrade) > 5)){
                    do{
                        System.out.print("\nPlease Enter Grade Level (1-5) : ");
                        givenGrade = sc.nextLine();
                    }while(givenGrade.equalsIgnoreCase("") || !LessonBookingMainClass.validateInput(givenGrade) || (Integer.parseInt(givenGrade) < 0 || Integer.parseInt(givenGrade) > 5));
                }   viewLessons("",givenGrade,"");
                break;
            case FILTER_BY_INSTRUCTOR:
                System.out.print("Please Enter Instructor Name (Wilson, Isobel, Denny, Sandy) : ");
                String givenInstructor = sc.nextLine();
                if(givenInstructor.equalsIgnoreCase("")){
                    do{
                        System.out.print("\nPlease Enter Instructor Name (Wilson, Isobel, Denny, Sandy) : ");
                        givenInstructor = sc.nextLine();
                    }while(givenInstructor.equalsIgnoreCase(""));
                }   if(!(givenInstructor.equalsIgnoreCase("Wilson") || givenInstructor.equalsIgnoreCase("Isobel") || givenInstructor.equalsIgnoreCase("Denny") ||
                        givenInstructor.equalsIgnoreCase("Sandy"))){
                    do{
                        System.out.print("\nPlease Enter Instructor Name (Wilson, Isobel, Denny, Sandy) : ");
                        givenInstructor = sc.nextLine();
                    }while(!(givenInstructor.equalsIgnoreCase("Wilson") || givenInstructor.equalsIgnoreCase("Isobel") || givenInstructor.equalsIgnoreCase("Denny") ||
                            givenInstructor.equalsIgnoreCase("Sandy")));
                }   viewLessons("","",givenInstructor);
                break;
            default:
                break;
        }
    }
    
    
    //View Lessons
    public static void viewLessons(String day, String level, String instructor){
       
                                   
        System.out.println("\n\n------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("| %-15s | %-30s | %-15s | %-15s | %-12s | %-15s | %-20s | %-10s |\n",
                "LessonsDataID","Title", "ClassGrade","Day", "Time", "Date", "Instructor", "Seats");
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------");
                              
        List<LessonsData> lessonInformationrmations = LessonsData.getLessonDataInformation();
        List<Instructors> instructorInformation = Instructors.getInstructorInformation();
        
        Set<String> uniqueRecords = new HashSet<>(); 
        for(LessonsData obj : lessonInformationrmations){
            if (!uniqueRecords.contains(String.valueOf(obj.getLessonUniqueNo()))){
                uniqueRecords.add(String.valueOf(obj.getLessonUniqueNo()));
                int instructorUniqueID = 0;
                
                for(Instructors iObj : instructorInformation){
                    if(iObj.getName().equalsIgnoreCase(instructor)){
                        instructorUniqueID = iObj.getUniqueInstructorNo();
                        break;
                    }
                }
                
                String insName = "";
                for(Instructors iObj : instructorInformation){
                    if(iObj.getUniqueInstructorNo() == obj.getInstructorUniqueNo()){
                        insName = iObj.getName();
                        break;
                    }
                }
                if(!day.equalsIgnoreCase("") && obj.getDayName().equalsIgnoreCase(day)){
                     System.out.printf("| %-15s | %-30s | %-15s | %-15s | %-12s | %-15s | %-20s | %-10s |\n", 
                    obj.getLessonUniqueNo(),obj.getTitle(), obj.getLessonGradeLevel(),obj.getDayName(), obj.getLessonTime(),
                    obj.getLessonDate(),insName, obj.getAvailableSeats());
                }
                if(!level.equalsIgnoreCase("") && obj.getLessonGradeLevel() == Integer.parseInt(level)){
                    System.out.printf("| %-15s | %-30s | %-15s | %-15s | %-12s | %-15s | %-20s | %-10s |\n", 
                    obj.getLessonUniqueNo(),obj.getTitle(), obj.getLessonGradeLevel(),obj.getDayName(), obj.getLessonTime(),
                    obj.getLessonDate(),insName, obj.getAvailableSeats());
                }
                if(!instructor.equalsIgnoreCase("") && obj.getInstructorUniqueNo() == instructorUniqueID){
                   System.out.printf("| %-15s | %-30s | %-15s | %-15s | %-12s | %-15s | %-20s | %-10s |\n", 
                    obj.getLessonUniqueNo(),obj.getTitle(), obj.getLessonGradeLevel(),obj.getDayName(), obj.getLessonTime(),
                    obj.getLessonDate(),instructor, obj.getAvailableSeats());
                }
                if(instructor.equalsIgnoreCase("") && day.equalsIgnoreCase("") && level.equalsIgnoreCase("")){
                    System.out.printf("| %-15s | %-30s | %-15s | %-15s | %-12s | %-15s | %-20s | %-10s |\n", 
                    obj.getLessonUniqueNo(),obj.getTitle(), obj.getLessonGradeLevel(),obj.getDayName(), obj.getLessonTime(),
                    obj.getLessonDate(),insName, obj.getAvailableSeats());
                }
            }
        }
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------");

        if(LessonReservations.IS_BOOKING == 1){
            LessonReservations.book();
        }
        if(LessonReservations.IS_CHANGING == 1){
            LessonReservations.updateReservation();
        }
    }
    
    
     //Check lesson selected
    public static boolean checkLessonUniqueID(int lessonSelected){
        boolean verified = false;
        
        List<LessonsData> lessonInformation = LessonsData.getLessonDataInformation();
         for(LessonsData obj : lessonInformation){
            if(obj.getLessonUniqueNo() == lessonSelected){
                verified = true;
                break;
            }
        }
        return verified;
    }
    
    
     
    //Check lesson is of current grade
    public static boolean checkLessonGrade(int studentUniqueID, int lessonSelected){
        boolean verified = false;
        int currentLevel  = 0;
        int classLevel  = 0;
        //Lesson Grade
        List<LessonsData> lessonInformation = LessonsData.getLessonDataInformation();
         for(LessonsData obj : lessonInformation){
            if(obj.getLessonUniqueNo() == lessonSelected){
                classLevel = obj.getLessonGradeLevel();
                break;
            }
        }
        //Students current  Grade
        List<Students> studentInfo = Students.getStudentsInformation();
         for(Students obj : studentInfo){
            if(obj.getUniqueRollNo() == studentUniqueID){
                currentLevel = obj.getStudentsGradeLevel();
                break;
            }
        }
        if(classLevel > (currentLevel + 1) || (classLevel < currentLevel)){
            verified = true;
        }
        return verified;
    }
    
    
      
    //Check available seats of lessons
    public static boolean setSeats(int lessonSelected, int subt, int add){
        boolean verified = false;
        
        List<LessonsData> lessonInformation = LessonsData.getLessonDataInformation();
         for(LessonsData obj : lessonInformation){
            if(obj.getLessonUniqueNo() == lessonSelected && subt != 0){
                obj.setAvailableSeats(obj.getAvailableSeats() -subt);
                break;
            }
            else if(obj.getLessonUniqueNo() == lessonSelected && add != 0){
                obj.setAvailableSeats(obj.getAvailableSeats()+add);
                break;
            }
        }
        return verified;
    }
    
    
    //Check Seats available
    public static boolean checkAvailableSeats(int lessonSelected){
        boolean verified = false;
        int seats = 0;
        List<LessonsData> lessonInformation = LessonsData.getLessonDataInformation();
         for(LessonsData obj : lessonInformation){
            if(obj.getLessonUniqueNo() == lessonSelected){
                seats = obj.getAvailableSeats();
                break;
            }
        }
        if(seats == 0){
            verified = true;
        }
        return verified;
    }
    
    
    
}
